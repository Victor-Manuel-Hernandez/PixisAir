﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using IBM.Data.DB2.iSeries;

namespace PixisAirProject
{
    public partial class RonaldForm : Form
    {
        iDB2Connection conn;
        iDB2DataAdapter adapter;
        DataSet dataSet;
        public RonaldForm()
        {
            InitializeComponent();
        }

        private void menuButton_Click(object sender, EventArgs e)
        {
            //show menu form
            this.Hide();//hides current form
        }

        private void jobButton_Click(object sender, EventArgs e)
        {
            string sql;
            try
            {
                conn = new iDB2Connection("Datasource=deathstar.gtc.edu");
                conn.Open();
                sql = "Select * From JOBTYPE";
                adapter = new iDB2DataAdapter(sql, conn);
                dataSet = new DataSet();
                adapter.Fill(dataSet);
                listBox1.Items.Clear();

                foreach (DataRow wRow in dataSet.Tables[0].Rows)
                    listBox1.Items.Add(wRow[0] + "    " + wRow[1] + "  " + wRow[2] + "  " + wRow[3] + "  " + wRow[4]);
            }
            catch (Exception ex)
            {
                listBox1.Items.Add(ex.Message);
            }
            finally
            {
                conn.Close();
            }
        }

        private void workorderButton_Click(object sender, EventArgs e)
        {

        }

        private void tasksButton_Click(object sender, EventArgs e)
        {
            string cmdTxt = "INSERT INTO TASKS VALUES (@TASKID, @TASKDESC, @TASKHRS)";

            try
            {
                conn = new iDB2Connection("Datasource=deathstar.gtc.edu");
                conn.Open();
                iDB2Command cmd = new iDB2Command(cmdTxt, conn);
                cmd.DeriveParameters();
                cmd.Parameters["@TASKID"].Value = "TASKID0008";
                cmd.Parameters["@TASKDESC"].Value = "AAAAAAAAAAAAA";
                cmd.Parameters["@TASKHRS"].Value = 2.5;
                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                listBox1.Items.Add(ex.Message);
            }
            finally
            {
                conn.Close();
                listBox1.Items.Add("item inserted");
            }
        }
    }
}
