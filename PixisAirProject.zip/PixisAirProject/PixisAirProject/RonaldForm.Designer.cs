﻿namespace PixisAirProject
{
    partial class RonaldForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.jobButton = new System.Windows.Forms.Button();
            this.menuButton = new System.Windows.Forms.Button();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.workorderButton = new System.Windows.Forms.Button();
            this.tasksButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // jobButton
            // 
            this.jobButton.Location = new System.Drawing.Point(675, 87);
            this.jobButton.Name = "jobButton";
            this.jobButton.Size = new System.Drawing.Size(113, 23);
            this.jobButton.TabIndex = 0;
            this.jobButton.Text = "Show All Jobs";
            this.jobButton.UseVisualStyleBackColor = true;
            this.jobButton.Click += new System.EventHandler(this.jobButton_Click);
            // 
            // menuButton
            // 
            this.menuButton.Location = new System.Drawing.Point(675, 26);
            this.menuButton.Name = "menuButton";
            this.menuButton.Size = new System.Drawing.Size(113, 23);
            this.menuButton.TabIndex = 1;
            this.menuButton.Text = "menuButton";
            this.menuButton.UseVisualStyleBackColor = true;
            this.menuButton.Click += new System.EventHandler(this.menuButton_Click);
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.Location = new System.Drawing.Point(12, 15);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(632, 381);
            this.listBox1.TabIndex = 2;
            // 
            // workorderButton
            // 
            this.workorderButton.Location = new System.Drawing.Point(675, 136);
            this.workorderButton.Name = "workorderButton";
            this.workorderButton.Size = new System.Drawing.Size(113, 23);
            this.workorderButton.TabIndex = 3;
            this.workorderButton.Text = "Enter WorkSpace";
            this.workorderButton.UseVisualStyleBackColor = true;
            this.workorderButton.Click += new System.EventHandler(this.workorderButton_Click);
            // 
            // tasksButton
            // 
            this.tasksButton.Location = new System.Drawing.Point(675, 211);
            this.tasksButton.Name = "tasksButton";
            this.tasksButton.Size = new System.Drawing.Size(113, 23);
            this.tasksButton.TabIndex = 4;
            this.tasksButton.Text = "Add a Task";
            this.tasksButton.UseVisualStyleBackColor = true;
            this.tasksButton.Click += new System.EventHandler(this.tasksButton_Click);
            // 
            // RonaldForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.tasksButton);
            this.Controls.Add(this.workorderButton);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.menuButton);
            this.Controls.Add(this.jobButton);
            this.Name = "RonaldForm";
            this.Text = "RonaldForm";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button jobButton;
        private System.Windows.Forms.Button menuButton;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Button workorderButton;
        private System.Windows.Forms.Button tasksButton;
    }
}

